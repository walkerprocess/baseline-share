const searchForm = document.querySelector("#searchForm");
const searchInput = document.querySelector("#searchInput");
const statusBox = document.querySelector("#status");
const trackResults = document.querySelector("#trackResults");
const resultCount = document.querySelector("#resultCount");
const selectedTrack = document.querySelector("#selectedTrack");
const selectedTrackBadge = document.querySelector("#selectedTrackBadge");
const platformList = document.querySelector("#platformList");
const rankingTitle = document.querySelector("#ranking-title");

rankingTitle.textContent = "곡별 플랫폼 비교";

const scoreWeights = {
  quality: 0.52,
  availability: 0.28,
  confidence: 0.2,
};

const apiTimeoutMs = 6500;
const platformSignalCache = new Map();
let platformRenderId = 0;

const platformAudioSpecs = {
  "Apple Music": {
    codec: "ALAC",
    compression: "lossless",
    bitrateKbps: null,
    bitDepth: 24,
    sampleRateKHz: 192,
    tier: "hi-res-lossless",
    highQualityOption: true,
    baseQualityScore: 96,
  },
  "YouTube Music": {
    codec: "AAC / OPUS",
    compression: "lossy",
    bitrateKbps: 256,
    bitDepth: null,
    sampleRateKHz: null,
    tier: "high-lossy",
    highQualityOption: false,
    baseQualityScore: 58,
  },
  Spotify: {
    codec: "FLAC",
    compression: "lossless",
    bitrateKbps: null,
    bitDepth: 24,
    sampleRateKHz: 44.1,
    tier: "lossless-plus",
    highQualityOption: true,
    baseQualityScore: 84,
  },
  TIDAL: {
    codec: "HiRes FLAC",
    compression: "lossless",
    bitrateKbps: null,
    bitDepth: 24,
    sampleRateKHz: 192,
    tier: "hi-res-lossless",
    highQualityOption: true,
    baseQualityScore: 97,
  },
  Qobuz: {
    codec: "FLAC",
    compression: "lossless",
    bitrateKbps: null,
    bitDepth: 24,
    sampleRateKHz: 192,
    tier: "hi-res-lossless",
    highQualityOption: true,
    baseQualityScore: 95,
  },
  "Amazon Music": {
    codec: "FLAC",
    compression: "lossless",
    bitrateKbps: null,
    bitDepth: 24,
    sampleRateKHz: 192,
    tier: "hi-res-lossless",
    highQualityOption: true,
    baseQualityScore: 93,
  },
  Deezer: {
    codec: "FLAC",
    compression: "lossless",
    bitrateKbps: null,
    bitDepth: 16,
    sampleRateKHz: 44.1,
    tier: "cd-lossless",
    highQualityOption: true,
    baseQualityScore: 78,
  },
  SoundCloud: {
    codec: "업로드 원본",
    compression: "variable",
    bitrateKbps: null,
    bitDepth: null,
    sampleRateKHz: null,
    tier: "variable",
    highQualityOption: false,
    baseQualityScore: 50,
  },
  Bandcamp: {
    codec: "FLAC / WAV",
    compression: "lossless",
    bitrateKbps: null,
    bitDepth: null,
    sampleRateKHz: null,
    tier: "source-lossless",
    highQualityOption: true,
    baseQualityScore: 86,
  },
  Napster: {
    codec: "AAC / MP3",
    compression: "lossy",
    bitrateKbps: 320,
    bitDepth: null,
    sampleRateKHz: null,
    tier: "high-lossy",
    highQualityOption: false,
    baseQualityScore: 62,
  },
  Audiomack: {
    codec: "업로드 원본",
    compression: "variable",
    bitrateKbps: null,
    bitDepth: null,
    sampleRateKHz: null,
    tier: "variable",
    highQualityOption: false,
    baseQualityScore: 48,
  },
  Melon: {
    codec: "AAC / FLAC",
    compression: "mixed",
    bitrateKbps: 320,
    bitDepth: 16,
    sampleRateKHz: 44.1,
    tier: "mixed-cd",
    highQualityOption: true,
    baseQualityScore: 66,
  },
  Genie: {
    codec: "AAC / FLAC",
    compression: "mixed",
    bitrateKbps: 320,
    bitDepth: 16,
    sampleRateKHz: 44.1,
    tier: "mixed-cd",
    highQualityOption: true,
    baseQualityScore: 64,
  },
  Bugs: {
    codec: "AAC / FLAC",
    compression: "mixed",
    bitrateKbps: 320,
    bitDepth: 16,
    sampleRateKHz: 44.1,
    tier: "mixed-cd",
    highQualityOption: true,
    baseQualityScore: 64,
  },
  VIBE: {
    codec: "AAC",
    compression: "lossy",
    bitrateKbps: 320,
    bitDepth: null,
    sampleRateKHz: null,
    tier: "high-lossy",
    highQualityOption: false,
    baseQualityScore: 63,
  },
};

const platformProfiles = [
  {
    name: "Apple Music",
    confirmedBy: "iTunes 검색 API",
    maxFormat: "ALAC Lossless / Hi-Res 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 96,
    source: "https://support.apple.com/en-us/118295",
    searchUrl: (q, track) =>
      track?.trackViewUrl || `https://music.apple.com/search?term=${encodeURIComponent(q)}`,
    matchScore: ({ track, flags, genre }) => {
      let score = track?.trackViewUrl ? 92 : 42;
      if (genre.pop || genre.kpop || genre.classical || genre.jazz) score += 7;
      if (flags.longTail) score -= 28;
      if (flags.videoFirst) score -= 14;
      return score;
    },
  },
  {
    name: "YouTube Music",
    confirmedBy: "검색 링크 우선 확인",
    maxFormat: "공식 음원 또는 영상 음원",
    maxDetail: "최대 256 kbps AAC / OPUS",
    maxPotential: 58,
    source: "https://support.google.com/youtubemusic/answer/9076559",
    searchUrl: (q) => `https://music.youtube.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 74;
      if (genre.kpop || genre.electronic || genre.soundtrack) score += 9;
      if (flags.longTail) score += 24;
      if (flags.videoFirst) score += 22;
      if (flags.appleConfirmed && !flags.videoFirst) score -= 5;
      return score;
    },
  },
  {
    name: "Spotify",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "Lossless 또는 Very High 가능",
    maxDetail: "계정/지역에 따라 최대 24-bit / 44.1 kHz FLAC",
    maxPotential: 82,
    source: "https://support.spotify.com/article/audio-quality/",
    searchUrl: (q) => `https://open.spotify.com/search/${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 66;
      if (genre.pop || genre.kpop || genre.hipHop || genre.electronic) score += 17;
      if (genre.classical || genre.jazz) score -= 5;
      if (flags.longTail) score -= 10;
      if (flags.videoFirst) score -= 14;
      return score;
    },
  },
  {
    name: "TIDAL",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "FLAC / HiRes FLAC 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 97,
    source: "https://tidal.com/sound-quality",
    searchUrl: (q) => `https://listen.tidal.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 50;
      if (genre.classical || genre.jazz || genre.rnb || genre.hipHop) score += 18;
      if (genre.pop || genre.rock) score += 10;
      if (genre.kpop) score += 3;
      if (flags.longTail) score -= 18;
      if (flags.videoFirst) score -= 18;
      return score;
    },
  },
  {
    name: "Qobuz",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "Hi-Res 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 95,
    source: "https://www.qobuz.com/us-en/music/streaming/offers",
    searchUrl: (q) => `https://play.qobuz.com/search?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 40;
      if (genre.classical || genre.jazz) score += 30;
      if (genre.rock || genre.rnb) score += 11;
      if (genre.kpop || flags.longTail || flags.videoFirst) score -= 18;
      return score;
    },
  },
  {
    name: "Amazon Music",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "HD / Ultra HD 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 93,
    source: "https://www.amazon.com/music/unlimited/why-hd",
    searchUrl: (q) => `https://music.amazon.com/search/${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 49;
      if (genre.pop || genre.rock || genre.classical) score += 12;
      if (flags.longTail) score -= 12;
      if (flags.videoFirst) score -= 15;
      return score;
    },
  },
  {
    name: "Deezer",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "High Fidelity 가능",
    maxDetail: "16-bit / 44.1 kHz FLAC",
    maxPotential: 78,
    source: "https://support.deezer.com/hc/en-gb/articles/115003875329-High-Fidelity-HiFi",
    searchUrl: (q) => `https://www.deezer.com/search/${encodeURIComponent(q)}/track`,
    matchScore: ({ genre, flags }) => {
      let score = 45;
      if (genre.pop || genre.electronic || genre.rock) score += 13;
      if (flags.longTail) score -= 11;
      if (flags.videoFirst) score -= 12;
      return score;
    },
  },
  {
    name: "SoundCloud",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "업로드 원본에 따라 다름",
    maxDetail: "공식/비공식 업로드 품질 편차 큼",
    maxPotential: 50,
    source: "https://soundcloud.com",
    searchUrl: (q) => `https://soundcloud.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 57;
      if (genre.electronic || genre.hipHop) score += 18;
      if (flags.longTail || flags.videoFirst) score += 17;
      if (genre.classical || genre.jazz) score -= 12;
      return score;
    },
  },
  {
    name: "Bandcamp",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "구매 시 Lossless 다운로드 가능",
    maxDetail: "아티스트 제공 원본에 따라 FLAC/WAV 가능",
    maxPotential: 86,
    source: "https://bandcamp.com",
    searchUrl: (q) => `https://bandcamp.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 36;
      if (genre.electronic || genre.rock || genre.jazz) score += 18;
      if (flags.longTail) score += 8;
      if (genre.kpop || genre.pop) score -= 12;
      return score;
    },
  },
  {
    name: "Napster",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "스트리밍 음원",
    maxDetail: "지역/계정별 품질 확인 필요",
    maxPotential: 62,
    source: "https://app.napster.com",
    searchUrl: (q) => `https://app.napster.com/search?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 43;
      if (genre.pop || genre.rock || genre.hipHop) score += 10;
      if (flags.longTail || flags.videoFirst) score -= 9;
      return score;
    },
  },
  {
    name: "Audiomack",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "업로드 기반 스트리밍",
    maxDetail: "힙합/인디 계열 발견 가능성 강점",
    maxPotential: 48,
    source: "https://audiomack.com",
    searchUrl: (q) => `https://audiomack.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 42;
      if (genre.hipHop || genre.rnb) score += 24;
      if (flags.longTail) score += 8;
      if (genre.classical || genre.jazz) score -= 12;
      return score;
    },
  },
  {
    name: "Melon",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 66,
    source: "https://www.melon.com",
    searchUrl: (q) => `https://www.melon.com/search/total/index.htm?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 45;
      if (genre.kpop) score += 34;
      if (genre.pop) score += 10;
      if (flags.longTail || flags.videoFirst) score -= 10;
      return score;
    },
  },
  {
    name: "Genie",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 64,
    source: "https://www.genie.co.kr",
    searchUrl: (q) => `https://www.genie.co.kr/search/searchMain?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 43;
      if (genre.kpop) score += 32;
      if (genre.pop) score += 8;
      if (flags.longTail || flags.videoFirst) score -= 9;
      return score;
    },
  },
  {
    name: "Bugs",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 64,
    source: "https://music.bugs.co.kr",
    searchUrl: (q) => `https://music.bugs.co.kr/search/integrated?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 42;
      if (genre.kpop) score += 30;
      if (genre.pop || genre.rock) score += 8;
      if (flags.longTail || flags.videoFirst) score -= 8;
      return score;
    },
  },
  {
    name: "VIBE",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 63,
    source: "https://vibe.naver.com",
    searchUrl: (q) => `https://vibe.naver.com/search?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 42;
      if (genre.kpop) score += 31;
      if (genre.pop) score += 8;
      if (flags.longTail || flags.videoFirst) score -= 8;
      return score;
    },
  },
];

const fallbackTrack = {
  trackName: "검색어 기반 직접 찾기",
  artistName: "정확한 곡 결과가 없으면 YouTube Music 가능성을 높게 봅니다.",
  collectionName: "플랫폼 직접 검색",
  artworkUrl100: "",
  isFallback: true,
  relevance: 0,
};

function clampScore(value) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

function normalize(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokens(value) {
  return normalize(value).split(" ").filter(Boolean);
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function safeExternalUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol === "https:" || url.protocol === "http:") return url.href;
  } catch (error) {
    return "#";
  }
  return "#";
}

function getArtistText(track) {
  return String(track?.artistName || "").trim();
}

function getTitleText(track) {
  return String(track?.trackName || "").trim();
}

function getTrackCacheKey(track) {
  return normalize(`${getArtistText(track)} ${getTitleText(track)} ${track?.collectionName || ""}`);
}

function withTimeout(promise, timeoutMs = apiTimeoutMs) {
  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => reject(new Error("API timeout")), timeoutMs);
    promise
      .then(resolve)
      .catch(reject)
      .finally(() => window.clearTimeout(timeoutId));
  });
}

async function fetchJson(url) {
  const response = await withTimeout(fetch(url, { headers: { Accept: "application/json" } }));
  if (!response.ok) throw new Error(`API ${response.status}`);
  return response.json();
}

function fetchJsonp(url, callbackParam = "callback") {
  return new Promise((resolve, reject) => {
    const callbackName = `qualityFindJsonp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const script = document.createElement("script");
    const timeoutId = window.setTimeout(() => {
      cleanup();
      reject(new Error("JSONP timeout"));
    }, apiTimeoutMs);

    function cleanup() {
      window.clearTimeout(timeoutId);
      delete window[callbackName];
      script.remove();
    }

    window[callbackName] = (data) => {
      cleanup();
      resolve(data);
    };

    const separator = url.includes("?") ? "&" : "?";
    script.src = `${url}${separator}output=jsonp&${callbackParam}=${callbackName}`;
    script.onerror = () => {
      cleanup();
      reject(new Error("JSONP load failed"));
    };
    document.head.appendChild(script);
  });
}

function scoreRelevance(track, query) {
  const queryTokens = tokens(query);
  if (queryTokens.length === 0) return 0;

  const normalizedQuery = normalize(query);
  const normalizedTitle = normalize(track.trackName);
  const titleTokens = tokens(track.trackName);
  const haystack = normalize(`${track.artistName} ${track.trackName} ${track.collectionName}`);
  const hits = queryTokens.filter((token) => haystack.includes(token)).length;
  const titleHit = normalizedTitle.includes(normalizedQuery);
  const titleCovered = titleTokens.length > 0 && titleTokens.every((token) => normalizedQuery.includes(token));
  const versionWords = ["remix", "live", "cover", "edit", "sped", "slowed", "instrumental", "karaoke"];
  const unwantedVersion = versionWords.some(
    (word) => normalizedTitle.includes(word) && !normalizedQuery.includes(word),
  );
  const conciseTitle = titleTokens.length <= queryTokens.length;

  return clampScore(
    (hits / queryTokens.length) * 72 +
      (titleHit ? 18 : 0) +
      (titleCovered ? 16 : 0) +
      (conciseTitle ? 8 : 0) -
      (unwantedVersion ? 20 : 0),
  );
}

function detectGenre(track) {
  const text = normalize(
    `${track.primaryGenreName || ""} ${track.trackName || ""} ${track.collectionName || ""} ${
      track.artistName || ""
    }`,
  );

  return {
    classical: /classical|opera|orchestra|symphony|concerto|piano/.test(text),
    jazz: /jazz|blues/.test(text),
    rnb: /r b|rnb|soul/.test(text),
    hipHop: /hip hop|rap/.test(text),
    pop: /pop|dance/.test(text),
    kpop: /k pop|kpop|뉴진스|아이유|르세라핌|에스파|ive|blackpink|bts/.test(text),
    rock: /rock|metal|alternative/.test(text),
    electronic: /electronic|edm|house|techno|remix|dj/.test(text),
    soundtrack: /soundtrack|ost|score|anime|game/.test(text),
  };
}

function detectFlags(track, query) {
  const text = normalize(`${query} ${track.trackName || ""} ${track.collectionName || ""}`);
  const relevance = track.relevance ?? scoreRelevance(track, query);
  const videoFirst = /cover|live|remix|mashup|edit|sped up|slowed|instrumental|karaoke|unreleased|demo/.test(
    text,
  );

  return {
    appleConfirmed: Boolean(track.trackViewUrl && !track.isFallback),
    longTail: Boolean(track.isFallback || relevance < 45),
    videoFirst,
    relevance,
  };
}

function artistCreditName(recording) {
  return (recording?.["artist-credit"] || []).map((credit) => credit.name).join(" ");
}

function scoreExternalMatch(candidate, track) {
  const targetTitle = getTitleText(track);
  const targetArtist = getArtistText(track);
  const candidateTitle = candidate.trackName || candidate.title || "";
  const candidateArtist = candidate.artistName || "";
  const candidateAlbum = candidate.collectionName || candidate.albumTitle || "";
  const titleTokens = tokens(targetTitle);
  const artistTokens = tokens(targetArtist);
  const normalizedCandidateTitle = normalize(candidateTitle);
  const normalizedCandidateArtist = normalize(candidateArtist);
  const normalizedCandidateAlbum = normalize(candidateAlbum);
  const titleHits = titleTokens.filter((token) => normalizedCandidateTitle.includes(token)).length;
  const artistHits = artistTokens.filter((token) => normalizedCandidateArtist.includes(token)).length;
  const albumHits = titleTokens.filter((token) => normalizedCandidateAlbum.includes(token)).length;
  const titleScore = titleTokens.length ? (titleHits / titleTokens.length) * 100 : 0;
  const artistScore = artistTokens.length ? (artistHits / artistTokens.length) * 100 : 0;
  const albumScore = titleTokens.length ? (albumHits / titleTokens.length) * 100 : 0;
  const versionWords = ["cover", "piano", "lofi", "rendition", "karaoke", "tribute", "sped", "slowed"];
  const targetText = normalize(`${targetTitle} ${track?.collectionName || ""}`);
  const candidateText = normalize(`${candidateTitle} ${candidateAlbum}`);
  const versionPenalty = versionWords.some((word) => candidateText.includes(word) && !targetText.includes(word))
    ? 22
    : 0;

  return clampScore(titleScore * 0.52 + artistScore * 0.4 + albumScore * 0.08 - versionPenalty);
}

function summarizeMusicBrainzRecording(recording) {
  const releases = recording?.releases || [];
  const officialReleases = releases.filter((release) => release.status === "Official");
  const digitalReleases = releases.filter((release) =>
    (release.media || []).some((medium) => normalize(medium.format).includes("digital")),
  );
  const countries = [...new Set(releases.map((release) => release.country).filter(Boolean))].slice(0, 5);

  return {
    id: recording?.id,
    title: recording?.title,
    artist: artistCreditName(recording),
    score: recording?.score || 0,
    isrcs: recording?.isrcs || [],
    firstReleaseDate: recording?.["first-release-date"] || "",
    officialReleaseCount: officialReleases.length,
    digitalReleaseCount: digitalReleases.length,
    countries,
  };
}

async function fetchMusicBrainzSignal(track) {
  if (!track || track.isFallback) return { status: "skipped", evidence: [] };

  const artist = getArtistText(track);
  const title = getTitleText(track);
  const query = `artist:"${artist}" AND recording:"${title}"`;
  const url = `https://musicbrainz.org/ws/2/recording?query=${encodeURIComponent(query)}&fmt=json&limit=5`;
  const data = await fetchJson(url);
  const recordings = data.recordings || [];
  const best = recordings
    .map((recording) => {
      const summary = summarizeMusicBrainzRecording(recording);
      const matchScore = scoreExternalMatch(
        {
          trackName: summary.title,
          artistName: summary.artist,
        },
        track,
      );
      return {
        ...summary,
        matchScore,
        combinedScore: clampScore(summary.score * 0.55 + matchScore * 0.45),
      };
    })
    .sort((a, b) => b.combinedScore - a.combinedScore)[0];

  if (!best || best.combinedScore < 68) {
    return {
      status: "checked_no_match",
      evidence: ["MusicBrainz에서 이 곡과 충분히 일치하는 녹음 메타데이터를 찾지 못했습니다."],
    };
  }

  const evidence = [
    `MusicBrainz 녹음 메타데이터 확인: ${best.artist} - ${best.title}`,
    best.isrcs.length ? `ISRC ${best.isrcs[0]} 확인` : "ISRC는 확인되지 않았습니다.",
  ];

  if (best.firstReleaseDate) evidence.push(`최초 발매일 ${best.firstReleaseDate}`);
  if (best.officialReleaseCount > 0) evidence.push(`공식 릴리즈 ${best.officialReleaseCount}개 확인`);
  if (best.digitalReleaseCount > 0) evidence.push(`디지털 릴리즈 ${best.digitalReleaseCount}개 확인`);
  if (best.countries.length > 0) evidence.push(`발매 지역 신호: ${best.countries.join(", ")}`);

  return {
    status: "confirmed",
    score: best.combinedScore,
    data: best,
    evidence,
  };
}

async function fetchDeezerSignal(track) {
  if (!track || track.isFallback) return { status: "skipped", evidence: [] };

  const query = `${getArtistText(track)} ${getTitleText(track)}`.trim();
  const url = `https://api.deezer.com/search/track?q=${encodeURIComponent(query)}&limit=8`;
  const data = await fetchJsonp(url);
  const matches = (data.data || [])
    .map((item) => {
      const matchScore = scoreExternalMatch(
        {
          trackName: item.title_short || item.title,
          artistName: item.artist?.name,
          albumTitle: item.album?.title,
        },
        track,
      );
      return { item, matchScore };
    })
    .sort((a, b) => b.matchScore - a.matchScore);
  const best = matches[0];

  if (!best || best.matchScore < 72 || !best.item.readable) {
    return {
      status: "checked_no_match",
      evidence: ["Deezer 공개 검색에서 충분히 일치하는 재생 가능 트랙을 찾지 못했습니다."],
    };
  }

  const evidence = [
    `Deezer 공개 API에서 ${best.item.artist?.name || "아티스트"} - ${best.item.title_short || best.item.title} 확인`,
  ];
  if (best.item.isrc) evidence.push(`Deezer ISRC ${best.item.isrc} 확인`);
  if (best.item.rank) evidence.push(`Deezer rank ${best.item.rank.toLocaleString("ko-KR")}`);

  return {
    status: "confirmed",
    score: best.matchScore,
    link: best.item.link,
    data: best.item,
    evidence,
  };
}

async function fetchApiSignals(track) {
  const cacheKey = getTrackCacheKey(track);
  if (!cacheKey || track?.isFallback) {
    return {
      identity: { status: "skipped", evidence: [] },
      platforms: {},
    };
  }
  if (platformSignalCache.has(cacheKey)) return platformSignalCache.get(cacheKey);

  const [musicBrainzResult, deezerResult] = await Promise.allSettled([
    fetchMusicBrainzSignal(track),
    fetchDeezerSignal(track),
  ]);
  const identity =
    musicBrainzResult.status === "fulfilled"
      ? musicBrainzResult.value
      : { status: "error", evidence: ["MusicBrainz API 확인에 실패했습니다."] };
  const deezer =
    deezerResult.status === "fulfilled"
      ? deezerResult.value
      : { status: "error", evidence: ["Deezer API 확인에 실패했습니다."] };
  const platforms = {};

  if (track.trackViewUrl) {
    platforms["Apple Music"] = {
      status: "confirmed",
      availabilityScore: 96,
      link: track.trackViewUrl,
      evidence: ["iTunes Search API에서 Apple Music/iTunes 곡 링크를 확인했습니다."],
    };
  }

  platforms.Deezer =
    deezer.status === "confirmed"
      ? {
          status: "confirmed",
          availabilityScore: Math.max(84, deezer.score),
          link: deezer.link,
          evidence: deezer.evidence,
        }
      : {
          status: deezer.status,
          availabilityScore: 0,
          evidence: deezer.evidence,
        };

  const signals = { identity, platforms };
  platformSignalCache.set(cacheKey, signals);
  return signals;
}

function getPlatformSignal(signals, platformName) {
  return signals?.platforms?.[platformName] || { status: "estimated", evidence: [] };
}

function getAudioSpec(platformName) {
  return platformAudioSpecs[platformName] || {
    codec: "미확인",
    compression: "unknown",
    bitrateKbps: null,
    bitDepth: null,
    sampleRateKHz: null,
    tier: "unknown",
    highQualityOption: false,
    baseQualityScore: 40,
  };
}

function formatResolution(spec) {
  const parts = [];
  if (spec.bitDepth && spec.sampleRateKHz) parts.push(`${spec.bitDepth}-bit / ${spec.sampleRateKHz} kHz`);
  if (spec.bitrateKbps) parts.push(`${spec.bitrateKbps} kbps`);
  if (parts.length === 0) parts.push("곡/업로드별 변동");
  return parts.join(" · ");
}

function getQualityTierLabel(spec) {
  switch (spec.tier) {
    case "hi-res-lossless":
      return "Hi-Res Lossless";
    case "lossless-plus":
      return "Lossless+";
    case "cd-lossless":
      return "CD Lossless";
    case "source-lossless":
      return "Source Lossless";
    case "mixed-cd":
      return "Mixed / CD 가능";
    case "high-lossy":
      return "High Lossy";
    case "variable":
      return "업로드별 변동";
    default:
      return "미확인";
  }
}

function formatAudioSpec(spec) {
  const compression =
    {
      lossless: "무손실",
      lossy: "손실",
      mixed: "혼합",
      variable: "변동",
      unknown: "미확인",
    }[spec.compression] || spec.compression;
  return `${spec.codec} · ${formatResolution(spec)} · ${compression}`;
}

function getQualityScoreForPlatform(platform, matchScore, platformSignal) {
  const spec = getAudioSpec(platform.name);
  let score = spec.baseQualityScore;

  if (platformSignal.status === "confirmed") score += 5;
  if (platformSignal.status === "checked_no_match") score -= 8;
  if (matchScore < 55) score = Math.round(score * 0.62);
  if (matchScore < 40) score = Math.round(score * 0.42);

  return clampScore(score);
}

function getQualityOptionLabel(spec, platformSignal, matchScore) {
  if (platformSignal.status === "confirmed" && spec.highQualityOption) return "고음질 옵션 확인 가능";
  if (platformSignal.status === "confirmed") return "플랫폼 보유 확인";
  if (spec.highQualityOption && matchScore >= 55) return "고음질 옵션 가능";
  if (spec.highQualityOption) return "고음질 옵션 미확인";
  return "고음질 옵션 없음";
}

function getGenreLabels(genre) {
  const labels = [
    ["classical", "클래식"],
    ["jazz", "재즈"],
    ["rnb", "R&B"],
    ["hipHop", "힙합"],
    ["pop", "팝"],
    ["kpop", "K-pop"],
    ["rock", "록"],
    ["electronic", "일렉트로닉"],
    ["soundtrack", "OST"],
  ];

  return labels.filter(([key]) => genre[key]).map(([, label]) => label);
}

function estimateTrackQuality(platform, matchScore, flags, platformSignal) {
  const spec = getAudioSpec(platform.name);
  const score = getQualityScoreForPlatform(platform, matchScore, platformSignal);
  const qualityTier = getQualityTierLabel(spec);
  const optionLabel = getQualityOptionLabel(spec, platformSignal, matchScore);
  const specText = formatAudioSpec(spec);

  if (platform.name === "YouTube Music") {
    return {
      label: `${optionLabel} · ${qualityTier}`,
      detail: `${specText}. 공식 음원은 최대 256 kbps AAC/OPUS, 영상/업로드 기반 결과는 원본에 따라 달라질 수 있습니다.`,
      score,
      spec,
      qualityTier,
      optionLabel,
      specText,
    };
  }

  if (platform.name === "Apple Music" && flags.appleConfirmed) {
    return {
      label: `${optionLabel} · ${qualityTier}`,
      detail: `${specText}. 이 곡은 Apple/iTunes 검색에서 확인됐고, 실제 Hi-Res 제공 여부는 Apple Music 곡 화면에서 최종 확인합니다.`,
      score,
      spec,
      qualityTier,
      optionLabel,
      specText,
    };
  }

  return {
    label: `${optionLabel} · ${qualityTier}`,
    detail:
      platformSignal.status === "confirmed"
        ? `${specText}. API로 곡 보유를 확인했고, 해당 플랫폼의 최고 음질 옵션 기준으로 분류했습니다.`
        : `${specText}. 곡 보유 또는 해당 음질 제공 여부는 플랫폼에서 최종 확인이 필요합니다.`,
    score,
    spec,
    qualityTier,
    optionLabel,
    specText,
  };
}

function estimateConfidence(platform, matchScore, flags, genre, signals, platformSignal) {
  const genreLabels = getGenreLabels(genre);
  const spec = getAudioSpec(platform.name);
  const evidence = [];
  let score = 34;
  let label = "추정 낮음";
  let tone = "low";

  if (platformSignal.status === "confirmed") {
    score = Math.max(88, platformSignal.availabilityScore || 0);
    label = "API 확인";
    tone = "high";
    evidence.push(...platformSignal.evidence);
  } else if (platformSignal.status === "checked_no_match") {
    score = 42;
    label = "API 미확인";
    evidence.push(...platformSignal.evidence);
  } else if (platform.name === "Apple Music" && flags.appleConfirmed) {
    score = 92;
    label = "검색 확인";
    tone = "high";
    evidence.push("iTunes 검색 결과에서 곡 링크를 직접 확인했습니다.");
  } else if (platform.name === "YouTube Music" && flags.longTail) {
    score = 58;
    label = "직접 확인 권장";
    tone = "mid";
    evidence.push("검색 일치도가 약해 영상/비공식 업로드까지 찾는 플랫폼을 우선했습니다.");
  } else if (matchScore >= 78) {
    score = 70;
    label = "강한 추정";
    tone = "mid";
    evidence.push("장르와 플랫폼 성격이 잘 맞고 발견 가능성 점수가 높습니다.");
  } else if (matchScore >= 55) {
    score = 50;
    label = "보통 추정";
    tone = "mid";
    evidence.push("카탈로그 가능성은 있으나 이 플랫폼에서 곡 단위 확인은 필요합니다.");
  } else {
    evidence.push("이 곡을 해당 플랫폼에서 확인할 신호가 부족합니다.");
  }

  if (genreLabels.length > 0) {
    evidence.push(`감지 장르: ${genreLabels.join(", ")}`);
  }
  evidence.push(`음질 단위: ${formatAudioSpec(spec)}`);
  evidence.push(`고음질 옵션: ${spec.highQualityOption ? getQualityTierLabel(spec) : "없음"}`);
  if (signals?.identity?.status === "confirmed") {
    score = platformSignal.status === "confirmed" ? score : Math.min(82, score + 10);
    evidence.push(...signals.identity.evidence.slice(0, 3));
  }
  if (flags.videoFirst) {
    evidence.push("라이브/커버/리믹스 계열 검색어라 영상 중심 플랫폼에 가산했습니다.");
  }
  if (platformSignal.status !== "confirmed" && !flags.appleConfirmed && platform.name !== "Apple Music") {
    evidence.push("현재 단계에서는 이 플랫폼의 실제 보유 여부를 API로 검증하지 않았습니다.");
  }

  return { score: clampScore(score), label, tone, evidence: [...new Set(evidence)] };
}

function getPlatformReason(platformName, flags, genre, matchScore) {
  if (platformName === "Apple Music" && flags.appleConfirmed) {
    return "이 곡은 Apple/iTunes 검색에서 직접 확인되었습니다.";
  }
  if (platformName === "YouTube Music" && flags.longTail) {
    return "검색 결과가 없거나 약한 곡은 영상/비공식 업로드까지 잡는 YouTube Music을 우선합니다.";
  }
  if (platformName === "YouTube Music" && flags.videoFirst) {
    return "라이브, 리믹스, 커버 계열은 YouTube Music에서 발견될 가능성이 높습니다.";
  }
  if ((platformName === "TIDAL" || platformName === "Qobuz") && (genre.classical || genre.jazz)) {
    return "클래식/재즈 계열이라 고해상도 음원 플랫폼 가능성을 높게 봅니다.";
  }
  if (platformName === "Spotify" && (genre.pop || genre.kpop || genre.hipHop)) {
    return "대중음악 카탈로그 접근성이 좋아 이 곡의 발견 가능성을 높게 봅니다.";
  }
  if (matchScore < 45) {
    return "이 곡을 직접 확인할 수 있는 신호가 약해 낮게 분류했습니다.";
  }
  return "곡 제목, 장르, 검색 일치도 기준으로 이 곡의 플랫폼 가능성을 계산했습니다.";
}

function buildPlatformComparison(track, signals = {}) {
  const query = cleanQuery(track);
  const genre = detectGenre(track);
  const flags = detectFlags(track, query);

  return platformProfiles
    .map((platform) => {
      const platformSignal = getPlatformSignal(signals, platform.name);
      const heuristicMatchScore = clampScore(platform.matchScore({ track, genre, flags }));
      const matchScore =
        platformSignal.status === "confirmed"
          ? clampScore(Math.max(heuristicMatchScore, platformSignal.availabilityScore || 0))
          : platformSignal.status === "checked_no_match"
            ? clampScore(Math.min(heuristicMatchScore, Math.max(28, heuristicMatchScore - 14)))
            : heuristicMatchScore;
      const estimatedQuality = estimateTrackQuality(platform, matchScore, flags, platformSignal);
      const confidence = estimateConfidence(platform, matchScore, flags, genre, signals, platformSignal);
      const verifiedBoost = platform.name === "Apple Music" && flags.appleConfirmed ? 8 : 0;
      const youtubeFallbackBoost = platform.name === "YouTube Music" && flags.longTail ? 12 : 0;
      const songScore = clampScore(
        estimatedQuality.score * scoreWeights.quality +
          matchScore * scoreWeights.availability +
          confidence.score * scoreWeights.confidence +
          verifiedBoost +
          youtubeFallbackBoost,
      );

      return {
        ...platform,
        matchScore,
        estimatedQuality,
        confidence,
        verifiedByApi: platformSignal.status === "confirmed",
        apiLink: platformSignal.link,
        songScore,
        reason: getPlatformReason(platform.name, flags, genre, matchScore),
      };
    })
    .sort((a, b) => b.songScore - a.songScore || b.matchScore - a.matchScore);
}

function cleanQuery(track) {
  if (!track || track.isFallback) return searchInput.value.trim();
  return `${track.artistName} ${track.trackName}`.trim();
}

function setStatus(message) {
  statusBox.textContent = message;
}

function renderSelectedTrack(track) {
  const artwork = track.artworkUrl100
    ? `<img src="${safeExternalUrl(track.artworkUrl100.replace("100x100", "160x160"))}" alt="" />`
    : `<div class="placeholder-art"></div>`;
  const confidence = track.isFallback
    ? "직접 검색"
    : `검색 일치도 ${track.relevance ?? 0}%`;

  selectedTrack.innerHTML = `
    ${artwork}
    <div>
      <p class="muted">${escapeHtml(track.artistName || "아티스트 정보 없음")}</p>
      <h3>${escapeHtml(track.trackName)}</h3>
      <p class="muted">${escapeHtml(track.collectionName || "앨범 정보 없음")}</p>
      <span class="signal-chip">${escapeHtml(confidence)}</span>
    </div>
  `;
  selectedTrackBadge.textContent = track.isFallback ? "직접 찾기" : "곡별 비교";
}

async function renderPlatforms(track) {
  const renderId = ++platformRenderId;
  const query = cleanQuery(track);

  platformList.innerHTML = `
    <article class="loading-card">
      플랫폼 API와 메타데이터를 확인하는 중입니다.
    </article>
  `;

  let signals = {};
  try {
    signals = await fetchApiSignals(track);
  } catch (error) {
    signals = {};
  }
  if (renderId !== platformRenderId) return;

  const comparison = buildPlatformComparison(track, signals);

  platformList.innerHTML = comparison
    .map((platform, index) => {
      const href = safeExternalUrl(platform.apiLink || platform.searchUrl(query, track));
      const evidence = platform.confidence.evidence
        .map((item) => `<li>${escapeHtml(item)}</li>`)
        .join("");
      return `
        <article class="platform-card">
          <div class="rank-number">${index + 1}</div>
          <div class="platform-body">
            <div class="platform-top">
              <div>
                <div class="platform-name">${platform.name}</div>
                <div class="quality-row">
                  <span class="quality-chip">이 곡 기준 ${platform.estimatedQuality.label}</span>
                  <span class="signal-chip">${platform.confirmedBy}</span>
                  <span class="confidence-chip ${platform.confidence.tone}">신뢰도 ${platform.confidence.label}</span>
                  ${platform.verifiedByApi ? `<span class="api-chip">API 확인</span>` : ""}
                </div>
                <div class="audio-spec-row">
                  <span>${escapeHtml(platform.estimatedQuality.qualityTier)}</span>
                  <span>${escapeHtml(platform.estimatedQuality.spec.codec)}</span>
                  <span>${escapeHtml(formatResolution(platform.estimatedQuality.spec))}</span>
                  <span>${platform.estimatedQuality.spec.highQualityOption ? "고음질 옵션 있음" : "고음질 옵션 없음"}</span>
                </div>
              </div>
              <a class="listen-link" href="${href}" target="_blank" rel="noreferrer">열기</a>
            </div>
            <div class="comparison-grid">
              <div>
                <span class="metric-label">음질 점수</span>
                <strong>${platform.estimatedQuality.score}</strong>
              </div>
              <div>
                <span class="metric-label">곡 발견 가능성</span>
                <strong>${platform.matchScore}</strong>
              </div>
              <div>
                <span class="metric-label">추천 점수</span>
                <strong>${platform.songScore}</strong>
              </div>
              <div>
                <span class="metric-label">신뢰도</span>
                <strong>${platform.confidence.score}</strong>
              </div>
            </div>
            <div class="score-strip" aria-hidden="true">
              <span style="width: ${platform.songScore}%"></span>
            </div>
            <p class="platform-note">${platform.reason}</p>
            <ul class="evidence-list">${evidence}</ul>
            <div class="platform-meta">
              <span class="muted">${platform.estimatedQuality.detail}</span>
              <a class="source-link" href="${safeExternalUrl(platform.source)}" target="_blank" rel="noreferrer">품질 기준</a>
            </div>
          </div>
        </article>
      `;
    })
    .join("");
}

function createFallbackTrack(query) {
  return {
    ...fallbackTrack,
    trackName: query || fallbackTrack.trackName,
  };
}

function renderTracks(tracks) {
  trackResults.innerHTML = tracks
    .map((track, index) => {
      const artwork = track.artworkUrl100
        ? `<img src="${safeExternalUrl(track.artworkUrl100)}" alt="" />`
        : `<div class="placeholder-art"></div>`;
      const detail = track.isFallback
        ? "YouTube Music 우선 직접 검색"
        : `${track.artistName || "아티스트 정보 없음"} · 일치도 ${track.relevance ?? 0}%`;

      return `
        <button class="track-card" type="button" data-index="${index}" aria-pressed="${index === 0}">
          ${artwork}
          <span>
            <span class="title">${escapeHtml(track.trackName)}</span>
            <span class="meta">${escapeHtml(detail)}</span>
            <span class="meta">${escapeHtml(track.collectionName || "앨범 정보 없음")}</span>
          </span>
        </button>
      `;
    })
    .join("");

  trackResults.querySelectorAll(".track-card").forEach((button) => {
    button.addEventListener("click", () => {
      const index = Number(button.dataset.index);
      const track = tracks[index];
      trackResults
        .querySelectorAll(".track-card")
        .forEach((card) => card.setAttribute("aria-pressed", "false"));
      button.setAttribute("aria-pressed", "true");
      renderSelectedTrack(track);
      renderPlatforms(track);
    });
  });

  if (tracks.length > 0) {
    renderSelectedTrack(tracks[0]);
    renderPlatforms(tracks[0]);
  }
}

async function searchTracks(query) {
  const url = `https://itunes.apple.com/search?term=${encodeURIComponent(
    query,
  )}&entity=song&country=KR&limit=8`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("검색 서버 응답이 좋지 않습니다.");
  }
  const data = await response.json();
  return (data.results || [])
    .map((track) => ({
      ...track,
      relevance: scoreRelevance(track, query),
    }))
    .sort((a, b) => b.relevance - a.relevance);
}

function shouldShowDirectSearch(tracks) {
  if (tracks.length === 0) return true;
  const best = tracks[0]?.relevance ?? 0;
  return best < 58 || tracks.length < 3;
}

async function handleSearch(query) {
  const normalizedQuery = query.trim();
  if (!normalizedQuery) return;

  searchForm.classList.add("is-loading");
  setStatus("곡을 찾고, 이 곡 기준으로 플랫폼별 발견 가능성과 예상 품질을 비교하는 중입니다.");
  resultCount.textContent = "검색 중";
  trackResults.innerHTML = "";

  try {
    const foundTracks = await searchTracks(normalizedQuery);
    const tracks = shouldShowDirectSearch(foundTracks)
      ? [createFallbackTrack(normalizedQuery), ...foundTracks]
      : foundTracks;

    renderTracks(tracks);

    if (foundTracks.length === 0) {
      setStatus("곡 결과가 없어 YouTube Music 우선 직접 검색으로 분류했습니다.");
      resultCount.textContent = "직접 검색";
      return;
    }

    if (tracks[0].isFallback) {
      setStatus("검색 일치도가 낮아 YouTube Music 직접 검색을 가장 위에 두고, 잡힌 후보도 함께 비교합니다.");
    } else {
      setStatus("플랫폼 전체 순위가 아니라 선택한 곡 기준의 발견 가능성, 예상 품질, 추천 점수를 비교했습니다.");
    }
    resultCount.textContent = `${foundTracks.length}곡`;
  } catch (error) {
    renderTracks([createFallbackTrack(normalizedQuery)]);
    setStatus("곡 검색 API를 사용할 수 없어 YouTube Music 우선 직접 검색으로 전환했습니다.");
    resultCount.textContent = "오프라인";
  } finally {
    searchForm.classList.remove("is-loading");
  }
}

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  handleSearch(searchInput.value);
});

document.querySelectorAll("[data-query]").forEach((button) => {
  button.addEventListener("click", () => {
    searchInput.value = button.dataset.query;
    handleSearch(button.dataset.query);
  });
});

const initialQuery = new URLSearchParams(window.location.search).get("q");
if (initialQuery) {
  searchInput.value = initialQuery;
  handleSearch(initialQuery);
} else {
  renderPlatforms(createFallbackTrack(""));
}
