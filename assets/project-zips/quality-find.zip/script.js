const searchForm = document.querySelector("#searchForm");
const searchInput = document.querySelector("#searchInput");
const statusBox = document.querySelector("#status");
const trackResults = document.querySelector("#trackResults");
const resultCount = document.querySelector("#resultCount");
const selectedTrack = document.querySelector("#selectedTrack");
const selectedTrackBadge = document.querySelector("#selectedTrackBadge");
const platformList = document.querySelector("#platformList");
const rankingTitle = document.querySelector("#ranking-title");

rankingTitle.textContent = "곡별 플랫폼 비교";

const platformProfiles = [
  {
    name: "Apple Music",
    confirmedBy: "iTunes 검색 API",
    maxFormat: "ALAC Lossless / Hi-Res 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 96,
    source: "https://support.apple.com/en-us/118295",
    searchUrl: (q, track) =>
      track?.trackViewUrl || `https://music.apple.com/search?term=${encodeURIComponent(q)}`,
    matchScore: ({ track, flags, genre }) => {
      let score = track?.trackViewUrl ? 92 : 42;
      if (genre.pop || genre.kpop || genre.classical || genre.jazz) score += 7;
      if (flags.longTail) score -= 28;
      if (flags.videoFirst) score -= 14;
      return score;
    },
  },
  {
    name: "YouTube Music",
    confirmedBy: "검색 링크 우선 확인",
    maxFormat: "공식 음원 또는 영상 음원",
    maxDetail: "최대 256 kbps AAC / OPUS",
    maxPotential: 58,
    source: "https://support.google.com/youtubemusic/answer/9076559",
    searchUrl: (q) => `https://music.youtube.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 74;
      if (genre.kpop || genre.electronic || genre.soundtrack) score += 9;
      if (flags.longTail) score += 24;
      if (flags.videoFirst) score += 22;
      if (flags.appleConfirmed && !flags.videoFirst) score -= 5;
      return score;
    },
  },
  {
    name: "Spotify",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "Lossless 또는 Very High 가능",
    maxDetail: "계정/지역에 따라 최대 24-bit / 44.1 kHz FLAC",
    maxPotential: 82,
    source: "https://support.spotify.com/article/audio-quality/",
    searchUrl: (q) => `https://open.spotify.com/search/${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 66;
      if (genre.pop || genre.kpop || genre.hipHop || genre.electronic) score += 17;
      if (genre.classical || genre.jazz) score -= 5;
      if (flags.longTail) score -= 10;
      if (flags.videoFirst) score -= 14;
      return score;
    },
  },
  {
    name: "TIDAL",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "FLAC / HiRes FLAC 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 97,
    source: "https://tidal.com/sound-quality",
    searchUrl: (q) => `https://listen.tidal.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 50;
      if (genre.classical || genre.jazz || genre.rnb || genre.hipHop) score += 18;
      if (genre.pop || genre.rock) score += 10;
      if (genre.kpop) score += 3;
      if (flags.longTail) score -= 18;
      if (flags.videoFirst) score -= 18;
      return score;
    },
  },
  {
    name: "Qobuz",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "Hi-Res 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 95,
    source: "https://www.qobuz.com/us-en/music/streaming/offers",
    searchUrl: (q) => `https://play.qobuz.com/search?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 40;
      if (genre.classical || genre.jazz) score += 30;
      if (genre.rock || genre.rnb) score += 11;
      if (genre.kpop || flags.longTail || flags.videoFirst) score -= 18;
      return score;
    },
  },
  {
    name: "Amazon Music",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "HD / Ultra HD 가능",
    maxDetail: "최대 24-bit / 192 kHz",
    maxPotential: 93,
    source: "https://www.amazon.com/music/unlimited/why-hd",
    searchUrl: (q) => `https://music.amazon.com/search/${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 49;
      if (genre.pop || genre.rock || genre.classical) score += 12;
      if (flags.longTail) score -= 12;
      if (flags.videoFirst) score -= 15;
      return score;
    },
  },
  {
    name: "Deezer",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "High Fidelity 가능",
    maxDetail: "16-bit / 44.1 kHz FLAC",
    maxPotential: 78,
    source: "https://support.deezer.com/hc/en-gb/articles/115003875329-High-Fidelity-HiFi",
    searchUrl: (q) => `https://www.deezer.com/search/${encodeURIComponent(q)}/track`,
    matchScore: ({ genre, flags }) => {
      let score = 45;
      if (genre.pop || genre.electronic || genre.rock) score += 13;
      if (flags.longTail) score -= 11;
      if (flags.videoFirst) score -= 12;
      return score;
    },
  },
  {
    name: "SoundCloud",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "업로드 원본에 따라 다름",
    maxDetail: "공식/비공식 업로드 품질 편차 큼",
    maxPotential: 50,
    source: "https://soundcloud.com",
    searchUrl: (q) => `https://soundcloud.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 57;
      if (genre.electronic || genre.hipHop) score += 18;
      if (flags.longTail || flags.videoFirst) score += 17;
      if (genre.classical || genre.jazz) score -= 12;
      return score;
    },
  },
  {
    name: "Bandcamp",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "구매 시 Lossless 다운로드 가능",
    maxDetail: "아티스트 제공 원본에 따라 FLAC/WAV 가능",
    maxPotential: 86,
    source: "https://bandcamp.com",
    searchUrl: (q) => `https://bandcamp.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 36;
      if (genre.electronic || genre.rock || genre.jazz) score += 18;
      if (flags.longTail) score += 8;
      if (genre.kpop || genre.pop) score -= 12;
      return score;
    },
  },
  {
    name: "Napster",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "스트리밍 음원",
    maxDetail: "지역/계정별 품질 확인 필요",
    maxPotential: 62,
    source: "https://app.napster.com",
    searchUrl: (q) => `https://app.napster.com/search?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 43;
      if (genre.pop || genre.rock || genre.hipHop) score += 10;
      if (flags.longTail || flags.videoFirst) score -= 9;
      return score;
    },
  },
  {
    name: "Audiomack",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "업로드 기반 스트리밍",
    maxDetail: "힙합/인디 계열 발견 가능성 강점",
    maxPotential: 48,
    source: "https://audiomack.com",
    searchUrl: (q) => `https://audiomack.com/search?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 42;
      if (genre.hipHop || genre.rnb) score += 24;
      if (flags.longTail) score += 8;
      if (genre.classical || genre.jazz) score -= 12;
      return score;
    },
  },
  {
    name: "Melon",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 66,
    source: "https://www.melon.com",
    searchUrl: (q) => `https://www.melon.com/search/total/index.htm?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 45;
      if (genre.kpop) score += 34;
      if (genre.pop) score += 10;
      if (flags.longTail || flags.videoFirst) score -= 10;
      return score;
    },
  },
  {
    name: "Genie",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 64,
    source: "https://www.genie.co.kr",
    searchUrl: (q) => `https://www.genie.co.kr/search/searchMain?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 43;
      if (genre.kpop) score += 32;
      if (genre.pop) score += 8;
      if (flags.longTail || flags.videoFirst) score -= 9;
      return score;
    },
  },
  {
    name: "Bugs",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 64,
    source: "https://music.bugs.co.kr",
    searchUrl: (q) => `https://music.bugs.co.kr/search/integrated?q=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 42;
      if (genre.kpop) score += 30;
      if (genre.pop || genre.rock) score += 8;
      if (flags.longTail || flags.videoFirst) score -= 8;
      return score;
    },
  },
  {
    name: "VIBE",
    confirmedBy: "플랫폼 검색 필요",
    maxFormat: "국내 음원 스트리밍",
    maxDetail: "국내 발매곡 접근성 우선",
    maxPotential: 63,
    source: "https://vibe.naver.com",
    searchUrl: (q) => `https://vibe.naver.com/search?query=${encodeURIComponent(q)}`,
    matchScore: ({ genre, flags }) => {
      let score = 42;
      if (genre.kpop) score += 31;
      if (genre.pop) score += 8;
      if (flags.longTail || flags.videoFirst) score -= 8;
      return score;
    },
  },
];

const fallbackTrack = {
  trackName: "검색어 기반 직접 찾기",
  artistName: "정확한 곡 결과가 없으면 YouTube Music 가능성을 높게 봅니다.",
  collectionName: "플랫폼 직접 검색",
  artworkUrl100: "",
  isFallback: true,
  relevance: 0,
};

function clampScore(value) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

function normalize(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokens(value) {
  return normalize(value).split(" ").filter(Boolean);
}

function scoreRelevance(track, query) {
  const queryTokens = tokens(query);
  if (queryTokens.length === 0) return 0;

  const normalizedQuery = normalize(query);
  const normalizedTitle = normalize(track.trackName);
  const titleTokens = tokens(track.trackName);
  const haystack = normalize(`${track.artistName} ${track.trackName} ${track.collectionName}`);
  const hits = queryTokens.filter((token) => haystack.includes(token)).length;
  const titleHit = normalizedTitle.includes(normalizedQuery);
  const titleCovered = titleTokens.length > 0 && titleTokens.every((token) => normalizedQuery.includes(token));
  const versionWords = ["remix", "live", "cover", "edit", "sped", "slowed", "instrumental", "karaoke"];
  const unwantedVersion = versionWords.some(
    (word) => normalizedTitle.includes(word) && !normalizedQuery.includes(word),
  );
  const conciseTitle = titleTokens.length <= queryTokens.length;

  return clampScore(
    (hits / queryTokens.length) * 72 +
      (titleHit ? 18 : 0) +
      (titleCovered ? 16 : 0) +
      (conciseTitle ? 8 : 0) -
      (unwantedVersion ? 20 : 0),
  );
}

function detectGenre(track) {
  const text = normalize(
    `${track.primaryGenreName || ""} ${track.trackName || ""} ${track.collectionName || ""} ${
      track.artistName || ""
    }`,
  );

  return {
    classical: /classical|opera|orchestra|symphony|concerto|piano/.test(text),
    jazz: /jazz|blues/.test(text),
    rnb: /r b|rnb|soul/.test(text),
    hipHop: /hip hop|rap/.test(text),
    pop: /pop|dance/.test(text),
    kpop: /k pop|kpop|뉴진스|아이유|르세라핌|에스파|ive|blackpink|bts/.test(text),
    rock: /rock|metal|alternative/.test(text),
    electronic: /electronic|edm|house|techno|remix|dj/.test(text),
    soundtrack: /soundtrack|ost|score|anime|game/.test(text),
  };
}

function detectFlags(track, query) {
  const text = normalize(`${query} ${track.trackName || ""} ${track.collectionName || ""}`);
  const relevance = track.relevance ?? scoreRelevance(track, query);
  const videoFirst = /cover|live|remix|mashup|edit|sped up|slowed|instrumental|karaoke|unreleased|demo/.test(
    text,
  );

  return {
    appleConfirmed: Boolean(track.trackViewUrl && !track.isFallback),
    longTail: Boolean(track.isFallback || relevance < 45),
    videoFirst,
    relevance,
  };
}

function estimateTrackQuality(platform, matchScore, flags) {
  if (platform.name === "YouTube Music") {
    if (matchScore >= 82) return { label: "발견 가능성 높음", detail: platform.maxDetail, score: 58 };
    return { label: "직접 검색 권장", detail: platform.maxDetail, score: 52 };
  }

  if (platform.name === "Apple Music" && flags.appleConfirmed) {
    return { label: "카탈로그 확인", detail: "무손실/Hi-Res 제공 여부는 Apple Music에서 확인", score: 88 };
  }

  if (matchScore >= 78) {
    return { label: platform.maxFormat, detail: "해당 곡이 있으면 고음질 옵션 가능성이 높음", score: platform.maxPotential };
  }
  if (matchScore >= 55) {
    return { label: "검색 후 품질 확인", detail: "카탈로그 가능성은 있으나 이 곡 품질은 미확인", score: Math.round(platform.maxPotential * 0.68) };
  }
  return { label: "미확인", detail: "이 곡 기준으로는 발견 신호가 약함", score: Math.round(platform.maxPotential * 0.28) };
}

function getPlatformReason(platformName, flags, genre, matchScore) {
  if (platformName === "Apple Music" && flags.appleConfirmed) {
    return "이 곡은 Apple/iTunes 검색에서 직접 확인되었습니다.";
  }
  if (platformName === "YouTube Music" && flags.longTail) {
    return "검색 결과가 없거나 약한 곡은 영상/비공식 업로드까지 잡는 YouTube Music을 우선합니다.";
  }
  if (platformName === "YouTube Music" && flags.videoFirst) {
    return "라이브, 리믹스, 커버 계열은 YouTube Music에서 발견될 가능성이 높습니다.";
  }
  if ((platformName === "TIDAL" || platformName === "Qobuz") && (genre.classical || genre.jazz)) {
    return "클래식/재즈 계열이라 고해상도 음원 플랫폼 가능성을 높게 봅니다.";
  }
  if (platformName === "Spotify" && (genre.pop || genre.kpop || genre.hipHop)) {
    return "대중음악 카탈로그 접근성이 좋아 이 곡의 발견 가능성을 높게 봅니다.";
  }
  if (matchScore < 45) {
    return "이 곡을 직접 확인할 수 있는 신호가 약해 낮게 분류했습니다.";
  }
  return "곡 제목, 장르, 검색 일치도 기준으로 이 곡의 플랫폼 가능성을 계산했습니다.";
}

function buildPlatformComparison(track) {
  const query = cleanQuery(track);
  const genre = detectGenre(track);
  const flags = detectFlags(track, query);

  return platformProfiles
    .map((platform) => {
      const matchScore = clampScore(platform.matchScore({ track, genre, flags }));
      const estimatedQuality = estimateTrackQuality(platform, matchScore, flags);
      const verifiedBoost = platform.name === "Apple Music" && flags.appleConfirmed ? 8 : 0;
      const youtubeFallbackBoost = platform.name === "YouTube Music" && flags.longTail ? 12 : 0;
      const songScore = clampScore(
        estimatedQuality.score * 0.62 + matchScore * 0.28 + verifiedBoost + youtubeFallbackBoost,
      );

      return {
        ...platform,
        matchScore,
        estimatedQuality,
        songScore,
        reason: getPlatformReason(platform.name, flags, genre, matchScore),
      };
    })
    .sort((a, b) => b.songScore - a.songScore || b.matchScore - a.matchScore);
}

function cleanQuery(track) {
  if (!track || track.isFallback) return searchInput.value.trim();
  return `${track.artistName} ${track.trackName}`.trim();
}

function setStatus(message) {
  statusBox.textContent = message;
}

function renderSelectedTrack(track) {
  const artwork = track.artworkUrl100
    ? `<img src="${track.artworkUrl100.replace("100x100", "160x160")}" alt="" />`
    : `<div class="placeholder-art"></div>`;
  const confidence = track.isFallback
    ? "직접 검색"
    : `검색 일치도 ${track.relevance ?? 0}%`;

  selectedTrack.innerHTML = `
    ${artwork}
    <div>
      <p class="muted">${track.artistName || "아티스트 정보 없음"}</p>
      <h3>${track.trackName}</h3>
      <p class="muted">${track.collectionName || "앨범 정보 없음"}</p>
      <span class="signal-chip">${confidence}</span>
    </div>
  `;
  selectedTrackBadge.textContent = track.isFallback ? "직접 찾기" : "곡별 비교";
}

function renderPlatforms(track) {
  const query = cleanQuery(track);
  const comparison = buildPlatformComparison(track);

  platformList.innerHTML = comparison
    .map((platform, index) => {
      const href = platform.searchUrl(query, track);
      return `
        <article class="platform-card">
          <div class="rank-number">${index + 1}</div>
          <div class="platform-body">
            <div class="platform-top">
              <div>
                <div class="platform-name">${platform.name}</div>
                <div class="quality-row">
                  <span class="quality-chip">이 곡 기준 ${platform.estimatedQuality.label}</span>
                  <span class="signal-chip">${platform.confirmedBy}</span>
                </div>
              </div>
              <a class="listen-link" href="${href}" target="_blank" rel="noreferrer">열기</a>
            </div>
            <div class="comparison-grid">
              <div>
                <span class="metric-label">예상 품질</span>
                <strong>${platform.estimatedQuality.score}</strong>
              </div>
              <div>
                <span class="metric-label">곡 발견 가능성</span>
                <strong>${platform.matchScore}</strong>
              </div>
              <div>
                <span class="metric-label">추천 점수</span>
                <strong>${platform.songScore}</strong>
              </div>
            </div>
            <div class="score-strip" aria-hidden="true">
              <span style="width: ${platform.songScore}%"></span>
            </div>
            <p class="platform-note">${platform.reason}</p>
            <div class="platform-meta">
              <span class="muted">${platform.estimatedQuality.detail}</span>
              <a class="source-link" href="${platform.source}" target="_blank" rel="noreferrer">품질 기준</a>
            </div>
          </div>
        </article>
      `;
    })
    .join("");
}

function createFallbackTrack(query) {
  return {
    ...fallbackTrack,
    trackName: query || fallbackTrack.trackName,
  };
}

function renderTracks(tracks) {
  trackResults.innerHTML = tracks
    .map((track, index) => {
      const artwork = track.artworkUrl100
        ? `<img src="${track.artworkUrl100}" alt="" />`
        : `<div class="placeholder-art"></div>`;
      const detail = track.isFallback
        ? "YouTube Music 우선 직접 검색"
        : `${track.artistName || "아티스트 정보 없음"} · 일치도 ${track.relevance ?? 0}%`;

      return `
        <button class="track-card" type="button" data-index="${index}" aria-pressed="${index === 0}">
          ${artwork}
          <span>
            <span class="title">${track.trackName}</span>
            <span class="meta">${detail}</span>
            <span class="meta">${track.collectionName || "앨범 정보 없음"}</span>
          </span>
        </button>
      `;
    })
    .join("");

  trackResults.querySelectorAll(".track-card").forEach((button) => {
    button.addEventListener("click", () => {
      const index = Number(button.dataset.index);
      const track = tracks[index];
      trackResults
        .querySelectorAll(".track-card")
        .forEach((card) => card.setAttribute("aria-pressed", "false"));
      button.setAttribute("aria-pressed", "true");
      renderSelectedTrack(track);
      renderPlatforms(track);
    });
  });

  if (tracks.length > 0) {
    renderSelectedTrack(tracks[0]);
    renderPlatforms(tracks[0]);
  }
}

async function searchTracks(query) {
  const url = `https://itunes.apple.com/search?term=${encodeURIComponent(
    query,
  )}&entity=song&country=KR&limit=8`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("검색 서버 응답이 좋지 않습니다.");
  }
  const data = await response.json();
  return (data.results || [])
    .map((track) => ({
      ...track,
      relevance: scoreRelevance(track, query),
    }))
    .sort((a, b) => b.relevance - a.relevance);
}

function shouldShowDirectSearch(tracks) {
  if (tracks.length === 0) return true;
  const best = tracks[0]?.relevance ?? 0;
  return best < 58 || tracks.length < 3;
}

async function handleSearch(query) {
  const normalizedQuery = query.trim();
  if (!normalizedQuery) return;

  searchForm.classList.add("is-loading");
  setStatus("곡을 찾고, 이 곡 기준으로 플랫폼별 발견 가능성과 예상 품질을 비교하는 중입니다.");
  resultCount.textContent = "검색 중";
  trackResults.innerHTML = "";

  try {
    const foundTracks = await searchTracks(normalizedQuery);
    const tracks = shouldShowDirectSearch(foundTracks)
      ? [createFallbackTrack(normalizedQuery), ...foundTracks]
      : foundTracks;

    renderTracks(tracks);

    if (foundTracks.length === 0) {
      setStatus("곡 결과가 없어 YouTube Music 우선 직접 검색으로 분류했습니다.");
      resultCount.textContent = "직접 검색";
      return;
    }

    if (tracks[0].isFallback) {
      setStatus("검색 일치도가 낮아 YouTube Music 직접 검색을 가장 위에 두고, 잡힌 후보도 함께 비교합니다.");
    } else {
      setStatus("플랫폼 전체 순위가 아니라 선택한 곡 기준의 발견 가능성, 예상 품질, 추천 점수를 비교했습니다.");
    }
    resultCount.textContent = `${foundTracks.length}곡`;
  } catch (error) {
    renderTracks([createFallbackTrack(normalizedQuery)]);
    setStatus("곡 검색 API를 사용할 수 없어 YouTube Music 우선 직접 검색으로 전환했습니다.");
    resultCount.textContent = "오프라인";
  } finally {
    searchForm.classList.remove("is-loading");
  }
}

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  handleSearch(searchInput.value);
});

document.querySelectorAll("[data-query]").forEach((button) => {
  button.addEventListener("click", () => {
    searchInput.value = button.dataset.query;
    handleSearch(button.dataset.query);
  });
});

const initialQuery = new URLSearchParams(window.location.search).get("q");
if (initialQuery) {
  searchInput.value = initialQuery;
  handleSearch(initialQuery);
} else {
  renderPlatforms(createFallbackTrack(""));
}
